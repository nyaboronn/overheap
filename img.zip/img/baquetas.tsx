<?xml version="1.0" encoding="UTF-8"?>
<tileset name="baquetas" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="../../../Imágenes/baquetas.png" width="124" height="118"/>
</tileset>
