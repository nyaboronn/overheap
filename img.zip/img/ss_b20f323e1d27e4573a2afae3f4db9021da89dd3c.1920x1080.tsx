<?xml version="1.0" encoding="UTF-8"?>
<tileset name="ss_b20f323e1d27e4573a2afae3f4db9021da89dd3c.1920x1080" tilewidth="4" tileheight="4" tilecount="57600" columns="320">
 <image source="../../../../../ss_b20f323e1d27e4573a2afae3f4db9021da89dd3c.1920x1080.jpg" width="1280" height="720"/>
</tileset>
