<?xml version="1.0" encoding="UTF-8"?>
<tileset name="newtiles" tilewidth="4" tileheight="4" tilecount="256" columns="16">
 <image source="newtiles.png" width="64" height="64"/>
</tileset>
